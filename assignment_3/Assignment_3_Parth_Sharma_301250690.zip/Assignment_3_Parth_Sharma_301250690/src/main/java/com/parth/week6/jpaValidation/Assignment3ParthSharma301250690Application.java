package com.parth.week6.jpaValidation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
/*
 * Name - PARTH SHARMA 
 * STUDENT NUMBER - 301250690
 * COURSE - COMP 303 SEC 001
 * 
 * 
 */
@SpringBootApplication
public class Assignment3ParthSharma301250690Application {

	public static void main(String[] args) {
		SpringApplication.run(Assignment3ParthSharma301250690Application.class, args);
	}

}
