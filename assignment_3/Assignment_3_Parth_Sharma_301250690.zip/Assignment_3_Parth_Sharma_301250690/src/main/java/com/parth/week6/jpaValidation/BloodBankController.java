package com.parth.week6.jpaValidation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


/*
 * Name - PARTH SHARMA 
 * STUDENT NUMBER - 301250690
 * COURSE - COMP 303 SEC 001
 * 
 * 
 */


@RestController
@RequestMapping("/bloodbanks")
public class BloodBankController {

    @Autowired
    private BloodBankService bloodBankService; // Autowired BloodBankService to handle BloodBank-related operations

    // Get all BloodBanks
    @GetMapping
    public List<BloodBank> getAllBloodBanks() {
        return bloodBankService.getAllBloodBanks();
    }

    // Get a BloodBank by ID
    @GetMapping("/{id}")
    public ResponseEntity<BloodBank> getBloodBankById(@PathVariable Long id) {
        return bloodBankService.getBloodBankById(id)
                .map(bloodBank -> new ResponseEntity<>(bloodBank, HttpStatus.OK))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    // Add a new BloodBank
    @PostMapping
    public ResponseEntity<Void> addBloodBank(@RequestBody BloodBank bloodBank) {
        bloodBankService.addBloodBank(bloodBank);
        return new ResponseEntity<>(HttpStatus.CREATED);
    }

    // Update an existing BloodBank by ID
    @PutMapping("/{id}")
    public ResponseEntity<Void> updateBloodBank(@PathVariable Long id, @RequestBody BloodBank bloodBank) {
        if (bloodBankService.getBloodBankById(id).isPresent()) {
            bloodBankService.updateBloodBank(id, bloodBank);
            return new ResponseEntity<>(HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    // Delete a BloodBank by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBloodBank(@PathVariable Long id) {
        bloodBankService.deleteBloodBank(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
