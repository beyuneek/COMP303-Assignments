package com.parth.week6.jpaValidation;

import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


/*
 * Name - PARTH SHARMA 
 * STUDENT NUMBER - 301250690
 * COURSE - COMP 303 SEC 001
 * 
 * 
 */
@Service
public class BloodBankService {

    private List<BloodBank> bloodBanks = new ArrayList<>(); // List to store BloodBank objects

    // Get all BloodBanks in the list
    public List<BloodBank> getAllBloodBanks() {
        return bloodBanks;
    }

    // Get a BloodBank by ID
    public Optional<BloodBank> getBloodBankById(Long id) {
        return bloodBanks.stream()
                         .filter(bloodBank -> id.equals(bloodBank.getId()))
                         .findFirst();
    }

    // Add a new BloodBank to the list
    public void addBloodBank(BloodBank bloodBank) {
        bloodBanks.add(bloodBank);
    }

    // Update an existing BloodBank by ID
    public void updateBloodBank(Long id, BloodBank updatedBloodBank) {
        for (int i = 0; i < bloodBanks.size(); i++) {
            BloodBank existingBloodBank = bloodBanks.get(i);
            if (existingBloodBank.getId() != null && existingBloodBank.getId().equals(id)) {
                bloodBanks.set(i, updatedBloodBank); // Update the existing record
                return; // Exit the method after updating
            }
        }
    }

    // Delete a BloodBank by ID
    public void deleteBloodBank(Long id) {
        bloodBanks.removeIf(bloodBank -> bloodBank.getId().equals(id));
    }
}