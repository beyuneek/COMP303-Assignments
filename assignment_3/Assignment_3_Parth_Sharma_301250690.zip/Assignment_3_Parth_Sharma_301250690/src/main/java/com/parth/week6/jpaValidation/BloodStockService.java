package com.parth.week6.jpaValidation;

import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
/*
 * Name - PARTH SHARMA 
 * STUDENT NUMBER - 301250690
 * COURSE - COMP 303 SEC 001
 * 
 * 
 */
@Service
public class BloodStockService {

    private List<BloodStock> bloodStocks = new ArrayList<>(); // List to store BloodStock objects

    // Get all BloodStocks in the list
    public List<BloodStock> getAllBloodStocks() {
        return bloodStocks;
    }

    // Get a BloodStock by ID
    public Optional<BloodStock> getBloodStockById(Long id) {
        return bloodStocks.stream()
                          .filter(bloodStock -> id.equals(bloodStock.getId()))
                          .findFirst();
    }

    // Add a new BloodStock to the list
    public void addBloodStock(BloodStock bloodStock) {
        bloodStocks.add(bloodStock);
    }

    // Update an existing BloodStock by ID
    public void updateBloodStock(Long id, BloodStock updatedBloodStock) {
        for (int i = 0; i < bloodStocks.size(); i++) {
            BloodStock existingBloodStock = bloodStocks.get(i);
            if (existingBloodStock.getId() != null && existingBloodStock.getId().equals(id)) {
                bloodStocks.set(i, updatedBloodStock); // Update the existing record
                return; // Exit the method after updating
            }
        }
    }

    // Delete a BloodStock by ID
    public void deleteBloodStock(Long id) {
        bloodStocks.removeIf(bloodStock -> bloodStock.getId().equals(id));
    }
}
