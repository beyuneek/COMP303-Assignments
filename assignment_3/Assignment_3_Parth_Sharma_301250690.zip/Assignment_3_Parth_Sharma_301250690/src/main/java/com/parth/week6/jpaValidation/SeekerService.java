package com.parth.week6.jpaValidation;

import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
/*
 * Name - PARTH SHARMA 
 * STUDENT NUMBER - 301250690
 * COURSE - COMP 303 SEC 001
 * 
 * 
 */
@Service
public class SeekerService {

    private List<Seeker> seekers = new ArrayList<>(); // List to store Seeker objects

    // Get all Seekers in the list
    public List<Seeker> getAllSeekers() {
        return seekers;
    }

    // Get a Seeker by ID
    public Optional<Seeker> getSeekerById(Long id) {
        return seekers.stream()
                      .filter(seeker -> id.equals(seeker.getId()))
                      .findFirst();
    }

    // Add a new Seeker to the list
    public void addSeeker(Seeker seeker) {
        seekers.add(seeker);
    }

    // Update an existing Seeker by ID
    public void updateSeeker(Long id, Seeker updatedSeeker) {
        for (int i = 0; i < seekers.size(); i++) {
            Seeker existingSeeker = seekers.get(i);
            if (existingSeeker.getId() != null && existingSeeker.getId().equals(id)) {
                seekers.set(i, updatedSeeker); // Update the existing record
                return; // Exit the method after updating
            }
        }
    }

    // Delete a Seeker by ID
    public void deleteSeeker(Long id) {
        seekers.removeIf(seeker -> seeker.getId().equals(id));
    }
}
