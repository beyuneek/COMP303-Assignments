package com.parth.week6.jpaValidation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
/*
 * Name - PARTH SHARMA 
 * STUDENT NUMBER - 301250690
 * COURSE - COMP 303 SEC 001
 * 
 * 
 */
@RestController
@RequestMapping("/bloodstocks")
public class BloodStockController {

    @Autowired
    private BloodStockService bloodStockService; // Autowired BloodStockService to handle BloodStock-related operations

    // Get all BloodStocks
    @GetMapping
    public List<BloodStock> getAllBloodStocks() {
        return bloodStockService.getAllBloodStocks();
    }

    // Get a BloodStock by ID
    @GetMapping("/{id}")
    public ResponseEntity<BloodStock> getBloodStockById(@PathVariable Long id) {
        return bloodStockService.getBloodStockById(id)
                .map(bloodStock -> new ResponseEntity<>(bloodStock, HttpStatus.OK))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    // Add a new BloodStock
    @PostMapping
    public ResponseEntity<Void> addBloodStock(@RequestBody BloodStock bloodStock) {
        bloodStockService.addBloodStock(bloodStock);
        return new ResponseEntity<>(HttpStatus.CREATED);
    }

    // Update an existing BloodStock by ID
    @PutMapping("/{id}")
    public ResponseEntity<Void> updateBloodStock(@PathVariable Long id, @RequestBody BloodStock bloodStock) {
        if (bloodStockService.getBloodStockById(id).isPresent()) {
            bloodStockService.updateBloodStock(id, bloodStock);
            return new ResponseEntity<>(HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    // Delete a BloodStock by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBloodStock(@PathVariable Long id) {
        bloodStockService.deleteBloodStock(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
