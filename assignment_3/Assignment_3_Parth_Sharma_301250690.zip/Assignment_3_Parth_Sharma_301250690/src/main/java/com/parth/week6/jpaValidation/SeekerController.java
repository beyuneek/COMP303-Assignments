package com.parth.week6.jpaValidation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
/*
 * Name - PARTH SHARMA 
 * STUDENT NUMBER - 301250690
 * COURSE - COMP 303 SEC 001
 * 
 * 
 */
@RestController
@RequestMapping("/seekers")
public class SeekerController {

    @Autowired
    private SeekerService seekerService; // Autowired SeekerService to handle Seeker-related operations

    @GetMapping
    public List<Seeker> getAllSeekers() {
        // GET request to fetch all Seekers
        return seekerService.getAllSeekers();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Seeker> getSeekerById(@PathVariable Long id) {
        // GET request to fetch a Seeker by ID
        return seekerService.getSeekerById(id)
                .map(seeker -> new ResponseEntity<>(seeker, HttpStatus.OK))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @PostMapping
    public ResponseEntity<Void> addSeeker(@RequestBody Seeker seeker) {
        // POST request to add a new Seeker
        seekerService.addSeeker(seeker);
        return new ResponseEntity<>(HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Void> updateSeeker(@PathVariable Long id, @RequestBody Seeker seeker) {
        // PUT request to update an existing Seeker by ID
        if (seekerService.getSeekerById(id).isPresent()) {
            seekerService.updateSeeker(id, seeker);
            return new ResponseEntity<>(HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteSeeker(@PathVariable Long id) {
        // DELETE request to delete a Seeker by ID
        seekerService.deleteSeeker(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
