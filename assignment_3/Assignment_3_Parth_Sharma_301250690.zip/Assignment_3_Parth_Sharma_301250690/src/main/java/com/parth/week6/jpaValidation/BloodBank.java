package com.parth.week6.jpaValidation;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;


/*
 * Name - PARTH SHARMA 
 * STUDENT NUMBER - 301250690
 * COURSE - COMP 303 SEC 001
 * 
 * 
 */
@Entity
public class BloodBank {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; // Unique identifier for the BloodBank entity
    private String bloodbankName; // Name of the blood bank
    private String address; // Address of the blood bank
    private String city; // City where the blood bank is located
    private String phone; // Phone number of the blood bank
    private String website; // Website URL of the blood bank
    private String email; // Email address of the blood bank

   
    
    public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getBloodbankName() {
		return bloodbankName;
	}
	public void setBloodbankName(String bloodbankName) {
		this.bloodbankName = bloodbankName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getWebsite() {
		return website;
	}
	public void setWebsite(String website) {
		this.website = website;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
    // Constructors, if needed, can be added here
}