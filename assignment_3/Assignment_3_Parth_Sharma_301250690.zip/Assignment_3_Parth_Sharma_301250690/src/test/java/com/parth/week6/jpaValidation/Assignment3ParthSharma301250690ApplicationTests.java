package com.parth.week6.jpaValidation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Assignment3ParthSharma301250690ApplicationTests {

	@Test
	void contextLoads() {
	}

}
