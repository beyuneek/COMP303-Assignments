package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParthAssignment1Comp303Sec001ApplicationTests {

	@Test
	void contextLoads() {
	}

}
