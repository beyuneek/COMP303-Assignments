package com.parth.midterm.exam;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class ReservationController {

    private final ReservationRepository repository;
    private static final String USERNAME = "user";
    private static final String PASSWORD = "user";


    @Autowired
    public ReservationController(ReservationRepository repository) {
        this.repository = repository;
    }

    @GetMapping("/")
    public String index() {
        return "index";
    }

    @GetMapping("/login")
    public String showLoginPage() {
        return "login";
    }

    @GetMapping("/reservations")
    public String showReservationForm() {
        return "reservation";
    }

    @PostMapping("/reservations/save")
    public String saveReservation(Reservation reservation) {
        repository.save(reservation);
        return "redirect:/show-reservations";
    }

    @GetMapping("/show-reservations")
    public String showReservations(Model model) {
        List<Reservation> reservations = repository.findAll();
        model.addAttribute("reservations", reservations);
        return "show-reservation";
    }
    
    @PostMapping("/login")
    public String handleLogin(@RequestParam String username, 
                              @RequestParam String password, 
                              Model model) {
        if (USERNAME.equals(username) && PASSWORD.equals(password)) {
            return "redirect:/reservations";  // Redirect to reservations if successful
        } else {
            model.addAttribute("errorMessage", "Invalid username or password!");
            return "login";
        }
    }

}
