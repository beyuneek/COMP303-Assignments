package com.parth.midterm.exam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParthSharma301250690MidtermApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParthSharma301250690MidtermApplication.class, args);
	}

}
