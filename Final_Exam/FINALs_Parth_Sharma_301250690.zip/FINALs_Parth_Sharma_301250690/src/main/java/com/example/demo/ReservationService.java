package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class ReservationService {

    private final ReservationRepository reservationRepository;
    private static final Logger log = LoggerFactory.getLogger(ReservationService.class);

    // Constructor injection of ReservationRepository
    @Autowired
    public ReservationService(ReservationRepository reservationRepository) {
        this.reservationRepository = reservationRepository;
    }

    // Create a reservation
    public Mono<Reservation> createReservation(Reservation reservation) {
        return reservationRepository.save(reservation);
    }

    // Get all reservations
    public Flux<Reservation> getAllReservations() {
        return reservationRepository.findAll();
    }

    // Get a reservation by its ID
    public Mono<Reservation> getReservationById(String id) {
        return reservationRepository.findById(id);
    }

    // Get reservations by last name
    public Flux<Reservation> getReservationsByLastName(String lastName) {
        return reservationRepository.findByLastName(lastName);
    }

    // Update a reservation by ID
    public Mono<Reservation> updateReservation(String id, Reservation updatedReservation) {
        return reservationRepository.findById(id)
                .doOnSuccess(found -> {
                    if (found == null) {
                        log.warn("Reservation with ID {} not found for update", id);
                    } else {
                        log.info("Updating reservation with ID {}", id);
                    }
                })
                .flatMap(reservation -> {
                    // Copy properties from updatedReservation to reservation here
                    reservation.setFirstName(updatedReservation.getFirstName());
                    reservation.setLastName(updatedReservation.getLastName());
                    reservation.setNumberOfPassengers(updatedReservation.getNumberOfPassengers());
                    reservation.setTravelClass(updatedReservation.getTravelClass());
                    reservation.setPhoneNumber(updatedReservation.getPhoneNumber());
                    reservation.setTimeOfFlight(updatedReservation.getTimeOfFlight());
                    reservation.setDateOfDeparture(updatedReservation.getDateOfDeparture());

                    log.info("Saving updated reservation: {}", reservation);
                    return reservationRepository.save(reservation);
                })
                .doOnError(error -> log.error("Error updating reservation", error));
    }

    // Delete a reservation by ID
    public Mono<Void> deleteReservation(String id) {
        return reservationRepository.deleteById(id);
    }

    
}
