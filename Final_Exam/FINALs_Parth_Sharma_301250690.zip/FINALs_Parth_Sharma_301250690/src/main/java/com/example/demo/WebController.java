package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class WebController {

    private final ReservationRepository reservationRepository;

    @Autowired
    public WebController(ReservationRepository reservationRepository) {
        this.reservationRepository = reservationRepository;
    }

    @GetMapping("/reservations")
    public String listReservations(Model model) {
        List<Reservation> reservations = reservationRepository.findAll().collectList().block(); // Blocking operation
        model.addAttribute("reservations", reservations);
        return "reservation-list"; // The Thymeleaf template that lists reservations
    }

    @GetMapping("/reservation")
    public String showReservationForm(Model model) {
        model.addAttribute("reservation", new Reservation());
        return "reservation-form"; // The Thymeleaf template for creating a new reservation
    }

    @PostMapping("/reservation")
    public String submitReservationForm(@ModelAttribute Reservation reservation) {
        reservationRepository.save(reservation).block(); // Blocking operation
        return "redirect:/reservations"; // Redirect to the list of reservations
    }

    @GetMapping("/reservation/edit/{id}")
    public String showEditReservationForm(@PathVariable String id, Model model) {
        Reservation reservation = reservationRepository.findById(id).block(); // Blocking operation
        model.addAttribute("reservation", reservation);
        return "edit-reservation"; // The Thymeleaf template for editing reservations
    }

    @PostMapping("/reservation/update/{id}")
    public String updateReservation(@PathVariable String id, @ModelAttribute Reservation reservation) {
        reservationRepository.save(reservation).block(); // Blocking operation
        return "redirect:/reservations"; // Redirect to the list of reservations
    }

    @PostMapping("/reservation/delete/{id}")
    public String deleteReservation(@PathVariable String id) {
        reservationRepository.deleteById(id).block(); // Blocking operation
        return "redirect:/reservations"; // Redirect to the list of reservations
    }

    // Other methods can be added as needed
}
