package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/api/reservations")
public class ReservationController {

    private final ReservationService reservationService;

    // Constructor injection of ReservationService
    @Autowired
    public ReservationController(ReservationService reservationService) {
        this.reservationService = reservationService;
    }

    // Create a new reservation via POST request
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Mono<Reservation> createReservation(@RequestBody Reservation reservation) {
        return reservationService.createReservation(reservation);
    }

    // Retrieve all reservations via GET request
    @GetMapping
    public Flux<Reservation> getAllReservations() {
        return reservationService.getAllReservations();
    }

    // Retrieve a reservation by its ID via GET request
    @GetMapping("/{id}")
    public Mono<Reservation> getReservationById(@PathVariable String id) {
        return reservationService.getReservationById(id);
    }

    // Update a reservation by its ID via PUT request
    @PutMapping("/{id}")
    public Mono<Reservation> updateReservation(@PathVariable String id, @RequestBody Reservation reservation) {
        return reservationService.updateReservation(id, reservation);
    }

    // Delete a reservation by its ID via DELETE request
    @DeleteMapping("/{id}")
    public Mono<Void> deleteReservation(@PathVariable String id) {
        return reservationService.deleteReservation(id);
    }

    // Additional endpoints can be added as needed
}
