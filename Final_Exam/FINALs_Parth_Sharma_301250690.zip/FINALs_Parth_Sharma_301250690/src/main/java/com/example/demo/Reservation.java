package com.example.demo;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.time.LocalDate;
import java.time.LocalTime;

@Document
public class Reservation {

    @Id
    private String id;

    // First Name of the passenger
    @Field
    private String firstName;

    // Last Name of the passenger
    @Field
    private String lastName;

    // Number of passengers
    @Field
    private int numberOfPassengers;

    // Travel class of the reservation (e.g., Economy, Business)
    @Field
    private String travelClass;

    // Phone number of the passenger
    @Field
    private String phoneNumber;

    // Time of the flight
    @Field
    private LocalTime timeOfFlight;

    // Date of departure
    @Field
    private LocalDate dateOfDeparture;

    // Constructors

    // Default constructor
    public Reservation() {
    }

    // Constructor with all fields
    public Reservation(String firstName, String lastName, int numberOfPassengers,
                       String travelClass, String phoneNumber, LocalTime timeOfFlight, LocalDate dateOfDeparture) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.numberOfPassengers = numberOfPassengers;
        this.travelClass = travelClass;
        this.phoneNumber = phoneNumber;
        this.timeOfFlight = timeOfFlight;
        this.dateOfDeparture = dateOfDeparture;
    }

    // Getters and Setters

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int getNumberOfPassengers() {
        return numberOfPassengers;
    }

    public void setNumberOfPassengers(int numberOfPassengers) {
        this.numberOfPassengers = numberOfPassengers;
    }

    public String getTravelClass() {
        return travelClass;
    }

    public void setTravelClass(String travelClass) {
        this.travelClass = travelClass;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public LocalTime getTimeOfFlight() {
        return timeOfFlight;
    }

    public void setTimeOfFlight(LocalTime timeOfFlight) {
        this.timeOfFlight = timeOfFlight;
    }

    public LocalDate getDateOfDeparture() {
        return dateOfDeparture;
    }

    public void setDateOfDeparture(LocalDate dateOfDeparture) {
        this.dateOfDeparture = dateOfDeparture;
    }

}
