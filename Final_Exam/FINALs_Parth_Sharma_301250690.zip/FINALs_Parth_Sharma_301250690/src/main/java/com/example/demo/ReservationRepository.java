package com.example.demo;

import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import java.time.LocalDate;

@Repository
public interface ReservationRepository extends ReactiveMongoRepository<Reservation, String> {

    // Example custom query method
    Flux<Reservation> findByLastName(String lastName);

    // You can define other query methods based on your requirements
}