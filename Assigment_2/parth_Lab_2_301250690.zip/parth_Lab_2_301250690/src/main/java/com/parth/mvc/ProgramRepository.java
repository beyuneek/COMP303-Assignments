package com.parth.mvc;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProgramRepository extends JpaRepository<Program, Integer> {
    Optional<Program> findById(Integer programCode);  // This is implicitly available, you don't need to define it
    Optional<Program> findByProgramName(String programName);
}