package com.parth.mvc;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.servlet.ModelAndView;

import jakarta.servlet.http.HttpSession;

@Controller  // Indicates that this is a Spring Controller
public class StudentController {

    // Dependency injections for repositories to handle data operations
    @Autowired
    private StudentRepository studentRepository;
    @Autowired
    private ProgramRepository programRepository;
    @Autowired
    private EnrollmentRepository enrollmentRepository;

    // Display the registration form
    @GetMapping("/")
    public ModelAndView showRegistrationForm() {
        return new ModelAndView("registration");
    }

    // Handle the registration form submission
    @PostMapping("/register")
    public String handleRegistration(Student student) {
        studentRepository.save(student);  // Save the student data to the database
        return "redirect:/login";  // Redirect to the login page after registration
    }

    // Display the login form
    @GetMapping("/login")
    public ModelAndView showLoginForm() {
        return new ModelAndView("login");
    }

    // Handle login form submission
    @PostMapping("/login")
    public ModelAndView handleLogin(@RequestParam String userName, @RequestParam String password, HttpSession session) {
        Optional<Student> studentOpt = studentRepository.findByUserName(userName);
        
        if (studentOpt.isPresent()) {
            Student student = studentOpt.get();
            String studentPassword = student.getPassword();
            
            if (studentPassword != null && studentPassword.equals(password)) {
                // Valid credentials: Store student info in the session and redirect
                session.setAttribute("loggedInStudent", student);
                return new ModelAndView("redirect:/programSelection");
            }
        }

        // Invalid credentials: Redirect back to login with an error message
        ModelAndView modelAndView = new ModelAndView("login");
        modelAndView.addObject("errorMessage", "Invalid username or password");
        return modelAndView;
    }

    // List all registered students
    @GetMapping("/students")
    public ModelAndView listStudents() {
        List<Student> students = studentRepository.findAll();
        return new ModelAndView("studentsList", "students", students);
    }

    // Display program selection for the student to choose from
    @GetMapping("/programSelection")
    public ModelAndView showProgramSelection() {
        List<Program> programs = programRepository.findAll();
        return new ModelAndView("programSelection", "programs", programs);
    }

    // Display the payment checkout form
    @GetMapping("/checkout")
    public ModelAndView showCheckoutForm() {
        return new ModelAndView("checkout");
    }

    // Process payment details (simplified version, real implementation would involve payment gateway integration)
    @PostMapping("/processPayment")
    public ModelAndView processPayment(@RequestParam String cardNumber, @RequestParam String expiryDate, @RequestParam String cvv) {
        return new ModelAndView("paymentSuccess");
    }

    // Display the profile of the logged-in student
    @GetMapping("/profile")
    public ModelAndView showProfile(HttpSession session) {
        Student loggedInStudent = (Student) session.getAttribute("loggedInStudent");
        if(loggedInStudent == null) {
            return new ModelAndView("errorPage", "errorMessage", "Please log in first");
        }

        Program selectedProgram = (Program) session.getAttribute("selectedProgram");

        ModelAndView modelAndView = new ModelAndView("profile");
        modelAndView.addObject("student", loggedInStudent);
        
        if(selectedProgram != null) {
            modelAndView.addObject("program", selectedProgram);
        }

        return modelAndView;
    }

    // Handle enrolling a student in a selected program
    @PostMapping("/enroll")
    public String enrollInProgram(@RequestParam Integer programCode, @SessionAttribute("loggedInStudent") Student student, HttpSession session) {
        Program program = programRepository.findById(programCode).orElseThrow(() -> new RuntimeException("Program not found"));

        Enrollment enrollment = new Enrollment();
        enrollment.setStudent(student);
        enrollment.setProgram(program);
        enrollmentRepository.save(enrollment);

        session.setAttribute("selectedProgram", program);
        return "redirect:/checkout";
    }

    // Display the profile editing form for the logged-in student
    @GetMapping("/editProfile")
    public ModelAndView showEditProfileForm(HttpSession session) {
        Student loggedInStudent = (Student) session.getAttribute("loggedInStudent");
        if(loggedInStudent == null) {
            return new ModelAndView("errorPage", "errorMessage", "Please log in first");
        }
        return new ModelAndView("editProfile", "student", loggedInStudent);
    }

    // Handle updating the profile details of the logged-in student
    @PostMapping("/updateProfile")
    public String handleProfileUpdate(Student updatedStudent, HttpSession session) {
        Student loggedInStudent = (Student) session.getAttribute("loggedInStudent");
        
        if(loggedInStudent == null) {
            return "redirect:/login";
        }

        // Update fields
        loggedInStudent.setFirstname(updatedStudent.getFirstname());
        loggedInStudent.setLastname(updatedStudent.getLastname());
        loggedInStudent.setUserName(updatedStudent.getUserName());
        loggedInStudent.setAddress(updatedStudent.getAddress());
        loggedInStudent.setCity(updatedStudent.getCity());
        loggedInStudent.setPostalCode(updatedStudent.getPostalCode());

        studentRepository.save(loggedInStudent);  // Save the updated student data

        return "redirect:/profile";
    }
}
