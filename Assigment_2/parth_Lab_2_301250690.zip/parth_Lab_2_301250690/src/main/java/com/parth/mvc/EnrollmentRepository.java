package com.parth.mvc;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface EnrollmentRepository extends JpaRepository<Enrollment, Integer> {
    // You can define custom methods here if needed
	List<Enrollment> findByStudent(Student student);
	
	
	@Query("SELECT e.program FROM Enrollment e WHERE e.student.id = :studentId")
	Optional<Program> findProgramByStudentId(@Param("studentId") Integer studentId);

}
