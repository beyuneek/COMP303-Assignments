package com.parth.mvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParthLab2301250690Application {

	public static void main(String[] args) {
		SpringApplication.run(ParthLab2301250690Application.class, args);
	}

}
