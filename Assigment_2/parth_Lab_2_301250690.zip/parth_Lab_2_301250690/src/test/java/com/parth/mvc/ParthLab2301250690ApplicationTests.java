package com.parth.mvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParthLab2301250690ApplicationTests {

	@Test
	void contextLoads() {
	}

}
