package com.parth.assignment_4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Assignment4ParthSharma301250690ApplicationTests {

	@Test
	void contextLoads() {
	}

}
