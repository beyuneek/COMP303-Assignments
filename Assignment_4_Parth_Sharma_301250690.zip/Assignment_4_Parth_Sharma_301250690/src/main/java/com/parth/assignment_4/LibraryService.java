package com.parth.assignment_4;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import com.parth.assignment_4.Book;
import com.parth.assignment_4.Publisher;
import com.parth.assignment_4.Member;
import com.parth.assignment_4.BookRepository;
import com.parth.assignment_4.PublisherRepository;
import com.parth.assignment_4.MemberRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class LibraryService {

    @Autowired
    private BookRepository bookRepository;

    @Autowired
    private PublisherRepository publisherRepository;

    @Autowired
    private MemberRepository memberRepository;

    // CRUD operations for Book
    public Mono<Book> createBook(Book book) {
        return bookRepository.save(book);
    }

    public Flux<Book> getAllBooks() {
        return bookRepository.findAll();
    }

    public Mono<Book> getBookById(String id) {
        return bookRepository.findById(id);
    }

    public Mono<Book> updateBook(String id, Book book) {
        return bookRepository.findById(id)
            .flatMap(existingBook -> {
                existingBook.setTitle(book.getTitle());
                existingBook.setAuthor(book.getAuthor());
                existingBook.setISBN(book.getISBN());
                existingBook.setPublisherId(book.getPublisherId());
                return bookRepository.save(existingBook);
            });
    }


    public Mono<Void> deleteBook(String id) {
        return bookRepository.deleteById(id);
    }

    
 // CRUD operations for Publisher
    public Mono<Publisher> createPublisher(Publisher publisher) {
        return publisherRepository.save(publisher);
    }

    public Flux<Publisher> getAllPublishers() {
        return publisherRepository.findAll();
    }

    public Mono<Publisher> getPublisherById(String id) {
        return publisherRepository.findById(id);
    }

    public Mono<Publisher> updatePublisher(String id, Publisher publisher) {
        return publisherRepository.findById(id)
            .flatMap(existingPublisher -> {
                existingPublisher.setName(publisher.getName());
                existingPublisher.setAddress(publisher.getAddress());
                // ... set other fields as necessary
                return publisherRepository.save(existingPublisher);
            });
    }


    public Mono<Void> deletePublisher(String id) {
        return publisherRepository.deleteById(id);
    }
    
    
    
 // CRUD operations for Member
    public Mono<Member> createMember(Member member) {
        return memberRepository.save(member);
    }

    public Flux<Member> getAllMembers() {
        return memberRepository.findAll();
    }

    public Mono<Member> getMemberById(String id) {
        return memberRepository.findById(id);
    }

    public Mono<Member> updateMember(String id, Member member) {
        return memberRepository.findById(id)
            .flatMap(existingMember -> {
                existingMember.setName(member.getName());
                existingMember.setEmail(member.getEmail());
                existingMember.setPhoneNumber(member.getPhoneNumber());
                // ... set other fields as necessary
                return memberRepository.save(existingMember);
            });
    }


    public Mono<Void> deleteMember(String id) {
        return memberRepository.deleteById(id);
    }  
}
