package com.parth.assignment_4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Assignment4ParthSharma301250690Application {

	public static void main(String[] args) {
		SpringApplication.run(Assignment4ParthSharma301250690Application.class, args);
	}

}
