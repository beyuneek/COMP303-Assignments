package com.parth.assignment_4;

import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import org.springframework.stereotype.Repository;
import com.parth.assignment_4.Member;

@Repository
public interface MemberRepository extends ReactiveMongoRepository<Member, String> {
    // Add custom query methods if needed
}
