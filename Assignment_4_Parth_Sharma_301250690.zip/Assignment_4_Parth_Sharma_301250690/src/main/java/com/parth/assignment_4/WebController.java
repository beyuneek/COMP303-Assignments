package com.parth.assignment_4;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.server.ServerWebExchange;
import org.thymeleaf.spring6.context.webflux.ReactiveDataDriverContextVariable;

import reactor.core.publisher.Mono;

@Controller
public class WebController {

    private final BookRepository bookRepository;
    @Autowired
    private MemberRepository memberRepository;
    @Autowired
   private PublisherRepository  publisherRepository;

    // Constructor-based autowiring
    @Autowired
    public WebController(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    // Display form to add a new book
    @GetMapping("/books/add")
    public Mono<String> addBookForm(Model model) {
        model.addAttribute("Book", new Book());
        return Mono.just("add-book");
    }

    // Handle submission of the add book form
    @PostMapping("/books")
    public Mono<String> submitBookForm(@ModelAttribute Book book, ServerWebExchange exchange) {
        // Log the book to check if ISBN is being set
        System.out.println("Book submitted: " + book);

        // Save the book to the database, wait for the save operation to complete, and then redirect
        return bookRepository.save(book)
                .flatMap(savedBook -> Mono.just("redirect:/books"));
    }

    // List all books
    @GetMapping("/books")
    public Mono<String> listBooks(Model model) {
        return bookRepository.findAll()
                .collectList()  // Convert the Flux<Book> to a List<Book>
                .doOnNext(books -> {
                    model.addAttribute("books", books);
                    // Log the books to ensure they are being fetched
                    System.out.println("Fetched books: " + books);
                })
                .thenReturn("list-books");
    }
    @PostMapping("/books/delete/{id}")
    public Mono<String> deleteBook(@PathVariable String id) {
        return bookRepository.deleteById(id)
                .thenReturn("redirect:/books");
    }
 // Display the update form
    @GetMapping("/books/edit/{id}")
    public Mono<String> showUpdateForm(@PathVariable String id, Model model) {
        return bookRepository.findById(id)
                .doOnNext(book -> model.addAttribute("book", book))
                .switchIfEmpty(Mono.error(new ResponseStatusException(HttpStatus.NOT_FOUND)))
                .thenReturn("update-book");
    }

    // Handle the update form submission
    @PostMapping("/books/update/{id}")
    public Mono<String> updateBook(@PathVariable String id, @ModelAttribute Book book) {
        return bookRepository.findById(id)
                .flatMap(existingBook -> {
                    existingBook.setTitle(book.getTitle());
                    existingBook.setAuthor(book.getAuthor());
                    existingBook.setISBN(book.getISBN());
                    return bookRepository.save(existingBook);
                })
                .thenReturn("redirect:/books");
    }


    
    
    
    @GetMapping("/members/add")
    public Mono<String> addMemberForm(Model model) {
        model.addAttribute("member", new Member());
        return Mono.just("add-member");
    }

    @PostMapping("/members")
    public Mono<String> submitMemberForm(@ModelAttribute Member member) {
        return memberRepository.save(member)  // Here we are calling save() on the memberRepository instance
                .flatMap(savedMember -> Mono.just("redirect:/members"));
    }

    
    @GetMapping("/members")
    public Mono<String> listMembers(Model model) {
        model.addAttribute("members", memberRepository.findAll());
        return Mono.just("list-members");
    }
    
    
    
    @GetMapping("/publishers/add")
    public Mono<String> addPublisherForm(Model model) {
        model.addAttribute("publisher", new Publisher());
        return Mono.just("add-publisher");
    }

    @PostMapping("/publishers")
    public Mono<String> submitPublisherForm(@ModelAttribute Publisher publisher) {
        return publisherRepository.save(publisher)
                .flatMap(savedPublisher -> Mono.just("redirect:/publishers"));
    }
    
    
    
    
    @GetMapping("/publishers")
    public Mono<String> listPublishers(Model model) {
        model.addAttribute("publishers", publisherRepository.findAll());
        return Mono.just("list-publishers");
    }





}
