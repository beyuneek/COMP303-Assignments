package com.parth.assignment_4;

import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import org.springframework.stereotype.Repository;
import com.parth.assignment_4.Book;
import reactor.core.publisher.Flux;

@Repository
public interface BookRepository extends ReactiveMongoRepository<Book, String> {
    // Example of a custom query method
    Flux<Book> findByAuthor(String author);
}
