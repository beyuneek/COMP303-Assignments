package com.parth.assignment_4;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/library")
public class LibraryController {

    @Autowired
    private LibraryService libraryService;

    // Book Endpoints
    @PostMapping("/books")
    public Mono<Book> createBook(@RequestBody Book book) {
        return libraryService.createBook(book);
    }

    @GetMapping("/books")
    public Flux<Book> getAllBooks() {
        return libraryService.getAllBooks();
    }

    @GetMapping("/books/{id}")
    public Mono<Book> getBookById(@PathVariable String id) {
        return libraryService.getBookById(id);
    }

    @PutMapping("/books/{id}")
    public Mono<Book> updateBook(@PathVariable String id, @RequestBody Book book) {
        return libraryService.updateBook(id, book);
    }

    @DeleteMapping("/books/{id}")
    public Mono<Void> deleteBook(@PathVariable String id) {
        return libraryService.deleteBook(id);
    }

 // Publisher Endpoints
    
    
    @PostMapping("/publishers")
    public Mono<Publisher> createPublisher(@RequestBody Publisher publisher) {
        return libraryService.createPublisher(publisher);
    }

    @GetMapping("/publishers")
    public Flux<Publisher> getAllPublishers() {
        return libraryService.getAllPublishers();
    }

    @GetMapping("/publishers/{id}")
    public Mono<Publisher> getPublisherById(@PathVariable String id) {
        return libraryService.getPublisherById(id);
    }

    @PutMapping("/publishers/{id}")
    public Mono<Publisher> updatePublisher(@PathVariable String id, @RequestBody Publisher publisher) {
        return libraryService.updatePublisher(id, publisher);
    }


    @DeleteMapping("/publishers/{id}")
    public Mono<Void> deletePublisher(@PathVariable String id) {
        return libraryService.deletePublisher(id);
    }
    
    
 // Member Endpoints
    @PostMapping("/members")
    public Mono<Member> createMember(@RequestBody Member member) {
        return libraryService.createMember(member);
    }

    @GetMapping("/members")
    public Flux<Member> getAllMembers() {
        return libraryService.getAllMembers();
    }

    @GetMapping("/members/{id}")
    public Mono<Member> getMemberById(@PathVariable String id) {
        return libraryService.getMemberById(id);
    }

    @PutMapping("/members/{id}")
    public Mono<Member> updateMember(@PathVariable String id, @RequestBody Member member) {
        return libraryService.updateMember(id, member);
    }


    @DeleteMapping("/members/{id}")
    public Mono<Void> deleteMember(@PathVariable String id) {
        return libraryService.deleteMember(id);
    }
}
